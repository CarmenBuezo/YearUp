// shopping cart empty to store click functions
var shoppingCart = [];
//
var round = 0;
//object array to group names and prices
var itemsInStore = {
	pasta: {
		name: "Pasta",
		price: 2.19
	},
	eggs: {
		name: "Eggs",
		price: 1.69
	},
	bananas: {
		name: "Bananas",
		price: 1.99
	},
	pizza: {
		name: "Pizza",
		price: 7.49
	},
	yogurt: {
		name: "Yogurt",
		price: 3.29
	},
	spinach: {
		name: "Spinach",
		price: 2.59
	},
	nuggets: {
		name: "Nuggets",
		price: 6.99
	},
	milk: {
		name: "Milk",
		price: 2.79
	},
	set1: {
		name: "Set1",
		price: 89.00
	},
	set2: {
		name: "Set2",
		price: 80.59
	},
	set3: {
		name: "Set3",
		price: 68.99
	},
	set4: {
		name: "Set4",
		price: 85.00
	},
	set5: {
		name: "Set5",
		price: 90.00
	},
	set6: {
		name: "Set6",
		price: 79.89
	},
	refrigerator: {
		name: "Refrigerator",
		price: 389.99
	},
	stove: {
		name: "Stove",
		price: 298.99
	},	
	microwave: {
		name: "Microwave",
		price: 89.99
	},
	sofa: {
		name: "Sofa",
		price: 299.99
	},
	poolTable: {
		name: "Pool Table",
		price: 115.95
	},	
	computer: {
		name: "Computer",
		price: 259.99
	},
	book1: {
		name: "Book1",
		price: 10.99
	},
	book2: {
		name: "Book2",
		price: 11.17
	},
	book3: {
		name: "Book3",
		price: 10.63
	},	
	book4: {
		name: "Book4",
		price: 12.74
	},
	book5: {
		name: "Book5",
		price: 14.89
	},									
};


function checkOut() {
    var total = 0;

	for(var i = 0; i < shoppingCart.length; i++) 
   {
   	total+= shoppingCart[i].price;
   }
   var tax = total * 7.5/100;
   var finalTotal = tax + total;
   round = (finalTotal).toFixed(2);
};

function addItem(item) {
	shoppingCart.push(itemsInStore[item]);
	alert(itemsInStore[item].name + " added to cart.");
};


function displayItems() {
var message = '';
for(var i=0; i < shoppingCart.length; i++){
	message = message+shoppingCart[i].name+': $'+shoppingCart[i].price+'\n\n'

};

checkOut();
message = message+'Total with sales tax is: $' + round +'\n\n';
// message = message+'We see that your items have not exceeded $100.00\n';
// message = message+'We will therefore only accept cash.\n';

alert(message);
};

function displayCheckOut() {
	checkOut();
	alert('Total with sales tax is: $' + round +'\n\n');
	if (round == 0.00) {
   		alert('There are no items in your cart.');
  	}
    else if (round > 100.00) {
   		alert('We see that your items have exceeded $100.00. A credit line can be set up for payment.');
   	}
   	else {
   		alert('We see that your items have not exceeded $100.00. We will therefore only accept cash.');
   }

};

//deleteItem
function deleteItem() {
	var removeFood = prompt( "Insert item name." );
	var removeFood1 = removeFood.toLowerCase();
	var indexOfItem = -1;
	for(var i = 0; i < shoppingCart.length; i++) 
   {
   	    var shoppingCartItemName = shoppingCart[i].name.toLowerCase();

   		if (shoppingCartItemName === removeFood1)
   		{
  			indexOfItem = i;
  			break;
  		}
	
   }

   if (indexOfItem > -1)
   {
   	shoppingCart.splice(indexOfItem, 1);
   }
   else
	 {
		alert("Item is not in your cart.")
	 }
};