function start() {
  document.turn = "X";
  if(Math.random()<0.5) {
    document.turn = "O"
  }
  document.winner = null;
  setMessage(document.turn + " gets to start");
}
function setMessage(msg) {
  document.getElementById("message").innerHTML = msg;
}
function nextMove(square) {
  if(document.winner != null) {
    setMessage(document.winner + " has won this round!");
  }else if (square.innerHTML == "") {
  square.innerHTML = document.turn;
  switchTurn();
  }
}
function switchTurn() {
  if (getWinner(document.turn)) {
    setMessage(document.turn + " you have won!");
    document.winner= document.turn;
  } else if ( document.turn === "X") {
    document.turn = "O" 
    setMessage("It's " + document.turn + "'s turn.");
  } else {
    document.turn="X";
    setMessage("It's " + document.turn + "'s turn.");
  }
 
}
function checkBoard(a,b,c,move) {
  var result= false;
    if (getInput(a) == move && getInput(b) == move && getInput(c) == move) {
      result = true;
    }
   return result;
}
function getInput(number) {
  return document.getElementById("t" + number).innerHTML;
}
function getWinner(move) {
  var result = false;
   if (checkBoard(1,2,3,move) || checkBoard(4,5,6,move) ||
     checkBoard(7,8,9,move) || checkBoard(1,4,7,move) ||
     checkBoard(2,5,8,move) || checkBoard(3,6,9,move) ||
     checkBoard(1,5,9,move) || checkBoard(3,5,7,move)) {
     result = true;
   }
  return result;
}
  
function setMessage(msg) {
  document.getElementById("message").innerHTML = msg;
}
function restart() {
  location.reload();
}