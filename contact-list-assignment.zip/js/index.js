function friends(firstName, lastName, phoneNumber, addressArray) {
  this.firstName = firstName;
  this.lastName = lastName;
  this.phoneNumber = phoneNumber;
  this.addressArray = addressArray;
}

var Bill = new friends("Bill", "Smith", "770-766-6565", ['One Microsoft Way', 'Redmond', 'WA', '98052']);
var Steve = new friends("Steve", "Williams", "404-866-3276", ['One Microsoft Way', 'Redmond', 'WA', '98052']);
var Angie = new friends("Angie", "Padilla", "678-769-3268", ['One Microsoft Way', 'Redmond', 'WA', '98052']);
var Julio = new friends("Julio", "Parada", "404-754-7768", ['One Microsoft Way', 'Redmond', 'WA', '98052']);
var Amna = new friends("Amna", "Anwar", "657-736-3647", ['One Microsoft Way', 'Redmond', 'WA', '98052']);

var friendArray = [Bill, Steve, Angie, Julio, Amna];

function list(listArray) {
  for (var f in listArray) {
    console.log(listArray[f]);
  }
};

function search(searchArray, name) {
  for (var s in searchArray) {
    if (searchArray[s] === name) {
      console.log(searchArray[s]);
    }
  }
};

console.log(Angie.phoneNumber);
search("Angie");